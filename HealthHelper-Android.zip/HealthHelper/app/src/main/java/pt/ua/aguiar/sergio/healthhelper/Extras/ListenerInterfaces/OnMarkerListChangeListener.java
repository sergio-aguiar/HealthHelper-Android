package pt.ua.aguiar.sergio.healthhelper.Extras.ListenerInterfaces;

import java.util.ArrayList;

import pt.ua.aguiar.sergio.healthhelper.Extras.Structures.HealthHelperMarker;

public interface OnMarkerListChangeListener {
    void onMarkerListChangeListener(ArrayList<HealthHelperMarker> healthHelperMarkers);
}
