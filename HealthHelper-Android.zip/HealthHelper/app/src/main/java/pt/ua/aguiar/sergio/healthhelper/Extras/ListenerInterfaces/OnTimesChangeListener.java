package pt.ua.aguiar.sergio.healthhelper.Extras.ListenerInterfaces;

public interface OnTimesChangeListener {
    void onTimesChangeListener(int moving, int stopped);
}
