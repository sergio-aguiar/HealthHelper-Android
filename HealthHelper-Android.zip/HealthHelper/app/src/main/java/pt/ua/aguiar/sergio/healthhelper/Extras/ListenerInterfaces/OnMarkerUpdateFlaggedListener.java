package pt.ua.aguiar.sergio.healthhelper.Extras.ListenerInterfaces;

import pt.ua.aguiar.sergio.healthhelper.Extras.Structures.HealthHelperMarker;

public interface OnMarkerUpdateFlaggedListener {
    void onMarkerCreatedListener(HealthHelperMarker marker);
}
