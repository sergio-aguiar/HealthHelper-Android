package pt.ua.aguiar.sergio.healthhelper.Extras.ListenerInterfaces;

import com.google.android.gms.maps.model.LatLng;

public interface OnLatLngChangeListener {
    void onLatLngChangeListener(LatLng position);
}
