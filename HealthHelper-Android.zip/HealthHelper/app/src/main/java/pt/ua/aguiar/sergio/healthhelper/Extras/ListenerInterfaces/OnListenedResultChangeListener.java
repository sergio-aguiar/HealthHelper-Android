package pt.ua.aguiar.sergio.healthhelper.Extras.ListenerInterfaces;

import pt.ua.aguiar.sergio.healthhelper.Extras.Structures.HealthHelperListenedResult;

public interface OnListenedResultChangeListener {
    void onListenedResultChangeListener(HealthHelperListenedResult result);
}
